import numpy
from scipy import *
#tab[line][column] starting at 0

sudoku2 = numpy.array([[3, 4, 1, 2],
                      [0, 2, 3, 0],
                      [0, 3, 2, 0],
                      [2, 1, 4, 3]])

sudoku = numpy.array([[0,3,0,1],
                      [1,4,3,2],
                      [3,2,1,4],
                      [0,1,0,3]])


group1 = [sudoku[0][0],sudoku[0][1],sudoku[1][0],sudoku[1][1]]
group2 = [sudoku[0][2],sudoku[0][3],sudoku[1][2],sudoku[1][3]]
group3 = [sudoku[2][0],sudoku[2][1],sudoku[3][0],sudoku[3][1]]
group4 = [sudoku[2][2],sudoku[2][3],sudoku[3][2],sudoku[3][3]]

i2=0
y2=0
while y2<4:
    while i2<4:
        if sudoku[y2][i2] == 0:
            #print('this is 0')
            if (y2 == 0 and i2 == 0) or (y2 == 0 and i2 == 1) or (y2 == 1 and i2 == 0) or (y2 == 1 and i2 == 1):
                #print('part of group 1')
                group = group1

            if (y2 == 0 and i2 == 2) or (y2 == 0 and i2 == 3) or (y2 == 1 and i2 == 2) or (y2 == 1 and i2 == 3):
                #print('part of group 2')
                group = group2

            if (y2 == 2 and i2 == 0) or (y2 == 2 and i2 == 1) or (y2 == 3 and i2 == 0) or (y2 == 3 and i2 == 1):
                #print('part of group 3')
                group = group3

            if (y2 == 2 and i2 == 2) or (y2 == 2 and i2 == 3) or (y2 == 3 and i2 == 2) or (y2 == 3 and i2 == 3):
                #print('part of group 4')
                group = group4

            x = 0
            while x<=4:
                if x not in group:
                    #print('%d is the answer'%x)
                    sudoku[y2][i2] = x
                x+=1

        i2+=1
    y2+=1
    i2=0

print(sudoku)