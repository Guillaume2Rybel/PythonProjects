import numpy
from scipy import *

sudoku2 = numpy.array([[3,4,1,0],
                      [0,2,0,0],
                      [0,0,2,0],
                      [0,1,4,3]])
                    
sudoku = numpy.array([[0,3,0,1],
                       [1,0,3,2],
                       [3,0,1,0],
                       [0,1,0,3]])
    

i=0
y=0
answer=0
while y<4:
    while i<4:
        print(sudoku[y][i])
        if sudoku[y][i]==0:
            print('this is 0')
            answer=0
            value=1
            while value<=4:
                if value not in sudoku[y,:] and value not in sudoku[:,i]:
                    print('it might be %d at %d-%d'%(value,y+1,i+1))
                    answer+=1
                    answer_value = value
                    value+=1

                else:
                    print('%d is allready present'%value)
                    value+=1
            
            if answer==1:
                print('there is only one answer')
                sudoku[y][i] = answer_value
        i+=1
    y+=1
    i=0

    print(sudoku)