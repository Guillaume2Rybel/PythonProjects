import numpy
from scipy import *

sudoku2 = numpy.array([[3,4,1,0],
                      [0,2,0,0],
                      [0,0,2,0],
                      [0,1,4,3]])
                    
sudoku1 = numpy.array([[0,3,0,1],
                       [1,0,3,2],
                       [3,0,1,0],
                       [0,1,0,3]])

print('Input all values, 0 = void')
value1 = int(input('value 1 : '))
value2 = int(input('value 2 : '))
value3 = int(input('value 3 : '))
value4 = int(input('value 4 : '))
value5 = int(input('\nvalue 5 : '))
value6 = int(input('value 6 : '))
value7 = int(input('value 7 : '))
value8 = int(input('value 8 : '))
value9 = int(input('\nvalue 9 : '))
value10 = int(input('value 10 : '))
value11 = int(input('value 11 : '))
value12 = int(input('value 12 : '))
value13 = int(input('\nvalue 13 : '))
value14 = int(input('value 14 : '))
value15 = int(input('value 15 : '))
value16 = int(input('value 16 : '))

sudoku = numpy.array([[value1,value2,value3,value4],
                       [value5,value6,value7,value8],
                       [value9,value10,value11,value12],
                       [value13,value14,value15,value16]])

#################check lines and colummns#################

#print(sudoku)

i=0
y=0
answer=0
while y<4:
    while i<4:
        #print(sudoku[y][i])
        if sudoku[y][i]==0:
            #print('this is 0')
            answer=0
            value=1
            while value<=4:
                if value not in sudoku[y,:] and value not in sudoku[:,i]:
                    #print('it might be %d at %d-%d'%(value,y+1,i+1))
                    answer+=1
                    answer_value = value
                    value+=1

                else:
                    #print('%d is allready present'%value)
                    value+=1
            
            if answer==1:
                #print('there is only one answer')
                sudoku[y][i] = answer_value
        i+=1
    y+=1
    i=0


#print(sudoku)

#################check groups#################
group1 = [sudoku[0][0],sudoku[0][1],sudoku[1][0],sudoku[1][1]]
group2 = [sudoku[0][2],sudoku[0][3],sudoku[1][2],sudoku[1][3]]
group3 = [sudoku[2][0],sudoku[2][1],sudoku[3][0],sudoku[3][1]]
group4 = [sudoku[2][2],sudoku[2][3],sudoku[3][2],sudoku[3][3]]

i2=0
y2=0
while y2<4:
    while i2<4:
        if sudoku[y2][i2] == 0:
            #print('this is 0')
            if (y2 == 0 and i2 == 0) or (y2 == 0 and i2 == 1) or (y2 == 1 and i2 == 0) or (y2 == 1 and i2 == 1):
                #print('part of group 1')
                group = group1

            if (y2 == 0 and i2 == 2) or (y2 == 0 and i2 == 3) or (y2 == 1 and i2 == 2) or (y2 == 1 and i2 == 3):
                #print('part of group 2')
                group = group2

            if (y2 == 2 and i2 == 0) or (y2 == 2 and i2 == 1) or (y2 == 3 and i2 == 0) or (y2 == 3 and i2 == 1):
                #print('part of group 3')
                group = group3

            if (y2 == 2 and i2 == 2) or (y2 == 2 and i2 == 3) or (y2 == 3 and i2 == 2) or (y2 == 3 and i2 == 3):
                #print('part of group 4')
                group = group4

            x = 0
            while x<=4:
                if x not in group:
                    #print('%d is the answer'%x)
                    sudoku[y2][i2] = x
                x+=1

        i2+=1
    y2+=1
    i2=0

print(sudoku)