import pygame, sys,  os, random, threading, time, math
mainClock = pygame.time.Clock()

from pygame.locals import *
from decimal import *

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()
pygame.mixer.set_num_channels(64)

pygame.display.set_caption('Asteroid rain')
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
font = pygame.font.Font('data/Pixeled.ttf', 16)
font_end = pygame.font.Font('data/Pixeled.ttf', 50)

background = pygame.image.load('data/images/backgrounds/background_pix.png')
img_ship = pygame.image.load('data/images/ship/ship.png')
img_ship = pygame.transform.scale(img_ship, (30,50))
img_asteroid = pygame.image.load('data/images/asteroid.png')

leave_button = pygame.image.load('data/images/end/leave.png')
restart_button = pygame.image.load('data/images/end/restart.png')

music = pygame.mixer.music.load('data/music/theme.wav')

######################################################################################

class Timer(threading.Thread):
 
    def __init__(self, function):
        threading.Thread.__init__(self)
        self.duration = 0.07
        self.function = function
        self.again = True
 
    def run(self):
        while self.again:
            self.timer = threading.Timer(self.duration, self.function)
            self.timer.setDaemon(True)
            self.timer.start()
            self.timer.join()
 
    def stop(self):
        self.again = False
        if self.timer.is_alive():
            self.timer.cancel()

######################################################################################    

class Game():

    def __init__(self):
        
        self.all_asteroids = pygame.sprite.Group()

    def draw_text(self, text, font, color, surface, x, y):
            
        textobj = font.render(text, 1, color)
        textrect = textobj.get_rect()
        textrect.topleft = (x, y)
        surface.blit(textobj, textrect)

    def launch_asteroids(self):

        self.all_asteroids.add(Asteroid())

    def end_screen(self, score):

        click = False

        while True:
            
            screen.blit(background, (0,0))

            mx, my = pygame.mouse.get_pos()

            leave_b = screen.blit(leave_button, (910,700))
            if leave_b.collidepoint((mx, my)):
                if click:
                    pygame.quit()
                    sys.exit()
                    
            restart_b = screen.blit(restart_button, (895,650))
            if restart_b.collidepoint((mx, my)):
                if click:
                    main()
            
            self.draw_text("GAME OVER", font_end, (255,255,255), screen, 730, 300)
            self.draw_text("Score : %s"%score, font, (255,255,255), screen, 900, 500)

            click = False
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        pygame.quit()
                        sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True

            pygame.display.update()
            mainClock.tick(60)
            
######################################################################################        

class Asteroid(pygame.sprite.Sprite):
    
    def __init__(self):
        
        super().__init__()
        self.velocity = 5
        self.image = img_asteroid
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, 1890)
        self.rect.y = 0

    def move(self):
        
        self.rect.y += self.velocity

    def move2(self):
        self.rect.y = random.randint(0, 1000)
        self.rect.x += self.velocity
    
######################################################################################    

class Ship(pygame.sprite.Sprite):
    
    def __init__(self):

        super().__init__()
        self.velocity = 7
        self.all_asteroids = pygame.sprite.Group()
        self.image = img_ship
        self.rect = self.image.get_rect()
        self.rect.x = 900
        self.rect.y = 500

    def showShip(self):
        
        screen.blit(self.image, (self.rect))

    def move_right(self):
        
        self.rect.x += self.velocity
        
    def move_left(self):
        
        self.rect.x -= self.velocity
        
    def move_up(self):
        
        self.rect.y -= self.velocity
        
    def move_down(self):
        self.rect.y += self.velocity

######################################################################################
        
def main():        
    ship = Ship()
    game = Game()

    moving_right = False
    moving_left = False
    moving_up = False
    moving_down = False

    click = False
    do_this = Timer(game.launch_asteroids)
    do_this.setDaemon(True)
    do_this.start()


    pygame.mixer.music.play(-1)
    
    while True:

        screen.blit(background, (0,0))
        game.all_asteroids.draw(screen)
        
        for asteroids in game.all_asteroids:
            asteroids.move()
            if ship.rect.colliderect(asteroids.rect):
                score = pygame.time.get_ticks()/100
                score = "%.f"%score
                game.end_screen(score)
                pygame.time.wait()  
            if asteroids.rect.y > 1000:
                game.all_asteroids.remove(asteroids)
            
        Ship.showShip(ship)

        #après un restart, reprendre les points à 0
        points = pygame.time.get_ticks() /100
        points_str = "%.f"%points
        points = round(points)
        game.draw_text(points_str, font, (255,255,255), screen, 10, 0)
        timing = round(do_this.duration, 2)
        game.draw_text("Interval : %s s"%timing, font, (255,255,255), screen, 10, 50)

        if points > 200:
            do_this.duration = 0.03
        if points > 400:
            do_this.duration = 0.05
        if points > 600:
            do_this.duration = 0.04
        if points > 800:
            do_this.duration = 0.03
        if points > 1000:
            do_this.duration = 0.02
        if points > 1200:
            do_this.duration = 0.01
        if points > 1500:
            do_this.duration = 0.001
        if points > 2000:
            do_this.duration = 0.000001
        
        
        if moving_right == True and ship.rect.x < 1890:
            ship.move_right()
        if moving_left == True and ship.rect.x > 0:
            ship.move_left()
        if moving_up == True and ship.rect.y > 0:
            ship.move_up()
        if moving_down == True and ship.rect.y < 1000:
            ship.move_down()
            
        mx, my = pygame.mouse.get_pos()    

        if click == True:
            ship.rect.x = mx
            ship.rect.y = my
            
        
        for event in pygame.event.get():
            
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
                
            if event.type == KEYDOWN:
                
                if event.key == K_d:
                    moving_right = True
                if event.key == K_a:
                    moving_left = True
                if event.key == K_w:
                    moving_up = True
                if event.key == K_s:
                    moving_down = True
                    
            if event.type == KEYUP:
                
                if event.key == K_d:
                    moving_right = False
                if event.key == K_a:
                    moving_left = False
                if event.key == K_w:
                    moving_up = False
                if event.key == K_s:
                    moving_down = False

            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
            if event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    click = False
                    
        pygame.display.update()
        mainClock.tick(60)

######################################################################################
######################################################################################

main()
